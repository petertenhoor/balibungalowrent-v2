<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="mphb-not-found">
	<?php esc_html_e( 'No accommodations matching criteria.', 'motopress-hotel-booking' ); ?>
</p>
