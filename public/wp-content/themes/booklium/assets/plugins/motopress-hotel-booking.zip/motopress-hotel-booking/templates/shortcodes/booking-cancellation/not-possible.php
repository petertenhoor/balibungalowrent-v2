<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'Cancelation of your booking is not possible for some reason. Please contact the website administrator.', 'motopress-hotel-booking' ); ?>
</p>
