<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="mphb-not-found">
	<?php esc_html_e( 'No services matched criteria.', 'motopress-hotel-booking' ); ?>
</p>
