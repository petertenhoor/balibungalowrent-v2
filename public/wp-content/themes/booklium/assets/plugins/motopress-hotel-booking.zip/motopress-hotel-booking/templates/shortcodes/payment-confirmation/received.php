<?php
/*
 * @since 3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'We are pleased to inform you that your reservation request has been received.', 'motopress-hotel-booking' ); ?>
</p>
